from ._cli.main import pysr as _cli

if __name__ == "__main__":
    _cli(prog_name="pysr")
